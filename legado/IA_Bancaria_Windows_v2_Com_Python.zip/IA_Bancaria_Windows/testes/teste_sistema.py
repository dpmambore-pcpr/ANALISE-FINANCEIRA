import base64,io,json,os,re,subprocess,tempfile,threading,unittest,urllib.error,urllib.request,zipfile
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
HERE=Path(__file__).resolve().parents[1]
requests_seen=[]
class FakeOllama(BaseHTTPRequestHandler):
 def log_message(self,*args): pass
 def do_GET(self):
  b=json.dumps({'models':[{'name':'teste-local:4b'},{'name':'teste:cloud'}]}).encode();self.send_response(200);self.end_headers();self.wfile.write(b)
 def do_POST(self):
  obj=json.loads(self.rfile.read(int(self.headers['Content-Length'])));requests_seen.append(obj)
  b=json.dumps({'response':'Resposta de teste, confira a fonte.'}).encode();self.send_response(200);self.end_headers();self.wfile.write(b)
class System(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.temp=tempfile.TemporaryDirectory()
  Path(cls.temp.name,'PROMPT_ANALISE_FINANCEIRA.txt').write_text('Fatos e fontes.',encoding='utf8')
  cls.fake=ThreadingHTTPServer(('127.0.0.1',11434),FakeOllama); threading.Thread(target=cls.fake.serve_forever,daemon=True).start()
  env={'HOME':cls.temp.name,'PATH':'/usr/bin:/bin','FINANCEIRA_HOME':cls.temp.name,'BROWSER':'true'}
  cls.proc=subprocess.Popen([str(HERE/'INICIAR_LINUX.sh')],cwd=HERE,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1)
  for _ in range(10):
   line=cls.proc.stdout.readline()
   m=re.search(r'(http://127\.0\.0\.1:\d+)/\?token=(\S+)',line)
   if m: cls.base,cls.token=m.groups();break
  else: raise RuntimeError('Servidor não iniciou')
 @classmethod
 def tearDownClass(cls): cls.proc.terminate();cls.proc.wait(timeout=5);cls.fake.shutdown();cls.temp.cleanup()
 def req(self,path,body=None,authorized=True,origin=None):
  hdr={}
  if authorized: hdr['X-App-Token']=self.token
  if origin: hdr['Origin']=origin
  data=None
  if body is not None: hdr['Content-Type']='application/json';data=json.dumps(body).encode()
  req=urllib.request.Request(self.base+path,data=data,headers=hdr)
  try:
   with urllib.request.urlopen(req,timeout=8) as r: return r.status,r.read(),dict(r.headers)
  except urllib.error.HTTPError as e: return e.code,e.read(),dict(e.headers)
 def test_everything(self):
  status,_,_=self.req('/api/cases',authorized=False);self.assertEqual(status,403)
  status,_,_=self.req('/api/cases',{'nome':'ataque'},origin='https://outra-origem.invalid');self.assertEqual(status,403)
  status,b,_=self.req('/api/cases',{'nome':'TESTE FICTÍCIO'});self.assertEqual(status,200);cid=json.loads(b)['id']
  blob=(HERE/'exemplos'/'EXEMPLO_FICTICIO_extrato.csv').read_bytes();encoded=base64.b64encode(blob).decode()
  base={'caso':cid,'nome':'ficticio.csv','conteudo':encoded}
  status,b,_=self.req('/api/preview',base);self.assertEqual(status,200);mapping=json.loads(b)['mapping']
  status,_,_=self.req('/api/import',{**base,'modo':'planilha','mapeamento':mapping});self.assertEqual(status,400)
  status,b,_=self.req('/api/import',{**base,'modo':'planilha','mapeamento':mapping,'confirmo_movimentacoes':True});self.assertEqual(status,200)
  status,_,_=self.req('/api/import',{**base,'modo':'planilha','mapeamento':mapping,'confirmo_movimentacoes':True});self.assertEqual(status,400)
  status,b,_=self.req('/api/query',{'caso':cid,'filtros':{}});self.assertEqual(status,200);d=json.loads(b);self.assertEqual(d['resumo']['creditos'],100000);self.assertEqual(d['resumo']['debitos'],45000)
  status,b,_=self.req('/api/models');self.assertEqual(json.loads(b)['modelos'],['teste-local:4b'])
  status,b,_=self.req('/api/ask',{'caso':cid,'modelo':'teste-local:4b','pergunta':'O que consta?','filtros':{}});self.assertEqual(status,200);self.assertIn('Resposta de teste',json.loads(b)['texto']);self.assertEqual(requests_seen[-1]['options']['num_ctx'],8192)
  status,_,_=self.req('/api/ask',{'caso':cid,'modelo':'teste:cloud','pergunta':'Pergunta','filtros':{}});self.assertEqual(status,400)
  pdf=base64.b64encode((HERE/'exemplos'/'EXEMPLO_FICTICIO_documento.pdf').read_bytes()).decode();status,b,_=self.req('/api/import',{'caso':cid,'nome':'teste.pdf','conteudo':pdf,'modo':'pdf'});self.assertEqual(status,200);source=json.loads(b)['id']
  status,b,_=self.req('/api/pdf?caso='+cid+'&fonte='+source);self.assertIn('FICTICIO',json.loads(b)['paginas'][0]['texto'])
  status,b,_=self.req('/api/askdoc',{'caso':cid,'fonte':source,'modelo':'teste-local:4b','pergunta':'O que diz o PDF?'});self.assertEqual(status,200);self.assertEqual(json.loads(b)['paginas_totais'],1)
  status,b,_=self.req('/api/diagrama',{'caso':cid,'filtros':{}});self.assertEqual(status,200);self.assertIn('R$ 450,00',json.loads(b)['svg'])
  png='iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/aWQAAAAASUVORK5CYII='
  status,b,_=self.req('/api/evidencia',{'caso':cid,'fonte':source,'pagina':1,'descricao':'Quadro fictício','marcas':[{'tipo':'retangulo','cor':'#d52222','x1':0,'y1':0,'x2':1,'y2':1}],'conteudo':png});self.assertEqual(status,200);ev=json.loads(b)['id']
  status,b,_=self.req('/api/evidencias?caso='+cid);self.assertEqual(status,200);self.assertEqual(len(json.loads(b)),1)
  status,b,_=self.req('/api/relatorio',{'caso':cid,'filtros':{},'evidencias':[ev],'observacoes':'Conferência fictícia'});self.assertEqual(status,200);report=base64.b64decode(json.loads(b)['conteudo']).decode();self.assertIn('Quadro fictício',report);self.assertIn('data:image/png;base64,',report);self.assertIn('R$ 450,00',report)
  status,b,h=self.req('/pdfjs/pdf.mjs',authorized=False);self.assertEqual(status,200);self.assertIn('javascript',h['Content-Type'])
  status,b,_=self.req('/api/cases',{'nome':'Pacote separado'});case2=json.loads(b)['id']
  blob2=(HERE/'exemplos'/'EXEMPLO_FICTICIO_simba_2010.zip').read_bytes();status,b,_=self.req('/api/import',{'caso':case2,'nome':'simba.zip','conteudo':base64.b64encode(blob2).decode(),'modo':'pacote'});self.assertEqual(status,200);pack=json.loads(b)['id']
  status,b,_=self.req('/api/archive?caso='+case2+'&fonte='+pack);self.assertEqual(len(json.loads(b)['itens']),3)
  status,b,_=self.req('/api/archive_simba',{'caso':case2,'fonte':pack});self.assertEqual(status,200);self.assertEqual(json.loads(b)['registros'],2)
  status,b,_=self.req('/api/archive?caso='+case2+'&fonte='+pack);self.assertEqual(status,200)
  status,b,h=self.req('/api/export.csv?caso='+cid+'&filtros=%7B%7D');self.assertEqual(status,200);self.assertIn('movimentos.csv',h['Content-Disposition']);self.assertIn('PESSOA BETA',b.decode('utf-8-sig'))
if __name__=='__main__':unittest.main(verbosity=2)
