from pathlib import Path
import csv,io,zipfile
p=Path(__file__).resolve().parents[1]/'exemplos'
p.mkdir(exist_ok=True)
with (p/'EXEMPLO_FICTICIO_extrato.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f,delimiter=';')
 w.writerow(['DATA_LANCAMENTO','NOME_TITULAR','CPF_CNPJ_TITULAR','NOME_BANCO','NOME_PESSOA_OD','CPF_CNPJ_OD','DESCRICAO_LANCAMENTO','VALOR_TRANSACAO','NATUREZA_LANCAMENTO'])
 w.writerows([['01/08/2026','MARIA EXEMPLO','00000000001','BANCO FICTICIO','PESSOA ALFA','00000000002','PIX recebido','1000,00','C'],['02/08/2026','MARIA EXEMPLO','00000000001','BANCO FICTICIO','PESSOA BETA','00000000003','PIX enviado','300,00','D'],['03/08/2026','MARIA EXEMPLO','00000000001','BANCO FICTICIO','PESSOA BETA','00000000003','PIX enviado','150,00','D'],['04/08/2026','MARIA EXEMPLO','00000000001','BANCO FICTICIO','','','Lançamento sem natureza','40,00','']])
def tsv(rows):
 s=io.StringIO(newline=''); w=csv.writer(s,delimiter='\t',lineterminator='\r\n');w.writerows(rows);return s.getvalue()
extrato=[['1','001','0001','12345','1','01082026','DOC1','DEPOSITO MULTIPLO','201','10000','C','10000','C','INTERNET']]
od=[['1','1','3000','DOC2','001','0001','12346','1','1','00000000002','ALFA FICTICIO','','','','','','',''],['2','1','7000','DOC3','001','0001','12347','1','1','00000000003','BETA FICTICIO','','','','','','','']]
tit=[['001','0001','12345','1','T','1','1','00000000001','MARIA FICTICIA','','','','','','','','','','','','']]
with zipfile.ZipFile(p/'EXEMPLO_FICTICIO_simba_2010.zip','w',zipfile.ZIP_DEFLATED) as z:
 z.writestr('EXTRATO.txt',tsv(extrato));z.writestr('ORIGEM_DESTINO.txt',tsv(od));z.writestr('TITULARES.txt',tsv(tit))
print('Exemplos fictícios criados.')
