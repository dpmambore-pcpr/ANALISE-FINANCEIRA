"""Empacota artefatos completos; escrita atomica para evitar ZIPs parciais."""
from pathlib import Path
import argparse,os,tempfile,zipfile
root=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser();parser.add_argument('--sistema',choices=['windows','linux','ambos'],default='ambos');args=parser.parse_args()
out=root.parent/'entregaveis';out.mkdir(exist_ok=True)
common=['financeira','vendor','licencas','exemplos','testes','LEIA_PRIMEIRO.txt','PROMPT_ANALISE_FINANCEIRA.txt','PROMPT_PARA_CURSOR.txt','iniciar.py']
variants=[('Linux',['INICIAR_LINUX.sh','INICIAR_OLLAMA_LINUX_PORTATIL.sh','runtime_linux'],'IA_Bancaria_Linux_v2.zip'),('Windows',['INICIAR_WINDOWS.bat','VERIFICAR_WINDOWS.bat','diagnosticar_windows.py','COMECE_AQUI_WINDOWS.txt','ORIGEM_PYTHON_PORTATIL.txt','runtime_windows'],'IA_Bancaria_Windows_v2_Com_Python.zip')]
for label,extra,filename in variants:
 if args.sistema!='ambos' and label.lower()!=args.sistema:continue
 for item in common+extra:
  if not (root/item).exists():raise FileNotFoundError('Componente necessario ausente: '+item)
 fd,tmp=tempfile.mkstemp(prefix='ia_bancaria_pacote_',suffix='.zip');os.close(fd)
 try:
  with zipfile.ZipFile(tmp,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6,allowZip64=True) as z:
   for item in common+extra:
    src=root/item;files=sorted(src.rglob('*')) if src.is_dir() else [src]
    for p in files:
     if not p.is_file() or '__pycache__' in p.parts or p.suffix=='.pyc' or 'dados' in p.parts:continue
     z.write(p,Path('IA_Bancaria_'+label)/p.relative_to(root))
  with zipfile.ZipFile(tmp) as z:
   error=z.testzip()
   if error:raise ValueError('ZIP invalido: '+error)
  size=os.path.getsize(tmp);target=out/filename;os.replace(tmp,target);print(label,str(target),size)
 finally:
  if os.path.exists(tmp):os.unlink(tmp)
