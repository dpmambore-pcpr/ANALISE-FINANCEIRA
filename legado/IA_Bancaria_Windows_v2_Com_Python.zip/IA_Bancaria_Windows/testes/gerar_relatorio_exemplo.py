from pathlib import Path
import os,sys,tempfile,io
import fitz
from PIL import Image,ImageDraw
root=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as tmp:
 os.environ['FINANCEIRA_HOME']=tmp;sys.path.insert(0,str(root/'financeira'))
 import core,visuais
 cid=core.make_case('TESTE FICTÍCIO - EXEMPLO')
 p=root/'exemplos'/'EXEMPLO_FICTICIO_extrato.csv'; blob=p.read_bytes();preview=core.preview(p.name,blob)
 core.import_table(cid,p.name,blob,preview['mapping'])
 p=root/'exemplos'/'EXEMPLO_FICTICIO_documento.pdf';pdf=p.read_bytes();src=core.import_pdf(cid,p.name,pdf)
 doc=fitz.open(stream=pdf,filetype='pdf');page=doc[0];pix=page.get_pixmap(matrix=fitz.Matrix(1.4,1.4),alpha=False)
 im=Image.open(io.BytesIO(pix.tobytes('png'))).convert('RGB');draw=ImageDraw.Draw(im)
 boxes=page.search_for('credito de R$ 1.000,00')
 if boxes:
  r=boxes[0];bounds=(int(r.x0*1.4)-6,int(r.y0*1.4)-4,int(r.x1*1.4)+6,int(r.y1*1.4)+4)
  draw.rectangle(bounds,outline=(220,30,35),width=4)
 im.save('/tmp/analise_bancaria_modelo/evidencia_ficticia.png')
 png=io.BytesIO();im.save(png,format='PNG')
 result=visuais.save_evidence(cid,src['id'],1,'Destaque fictício criado para demonstrar a marcação.',png.getvalue(),[{'tipo':'retangulo','cor':'#d52222','observacao':'exemplo fictício'}])
 out=visuais.report_html(cid,{},[result['id']],'ESTE É UM EXEMPLO FICTÍCIO. Valores e pessoas foram criados para demonstrar a apresentação. Toda análise real deve ser conferida nas fontes.')
 (root/'exemplos'/'EXEMPLO_RELATORIO_FICTICIO.html').write_bytes(out)
 print('Exemplo fictício criado:',len(out),'bytes')
