import io,os,sys,tempfile,unittest,zipfile,csv
from pathlib import Path
HERE=Path(__file__).resolve().parents[1]
TMP=tempfile.TemporaryDirectory();os.environ['FINANCEIRA_HOME']=TMP.name
sys.path.insert(0,str(HERE/'financeira'))
import core
class Banking(unittest.TestCase):
 def setUp(self): self.cid=core.make_case('CASO FICTÍCIO')
 def test_table_and_provenance(self):
  src=(HERE/'exemplos'/'EXEMPLO_FICTICIO_extrato.csv').read_bytes()
  p=core.preview('extrato.csv',src);self.assertEqual(p['total_rows'],4)
  result=core.import_table(self.cid,'extrato.csv',src,p['mapping'])
  d=core.query(self.cid);self.assertEqual(d['total'],4)
  self.assertEqual(d['resumo']['creditos'],100000);self.assertEqual(d['resumo']['debitos'],45000);self.assertEqual(d['resumo']['pendentes'],1)
  self.assertEqual(d['destinos'][0]['n'],2);self.assertEqual(d['destinos'][0]['centavos'],45000)
  self.assertEqual(len(d['registros'][0]['sha256']),64);self.assertIn('linha ',d['registros'][0]['local'])
  self.assertEqual(core.query(self.cid,{'titular':'mária exemplo'})['total'],4)
  self.assertEqual(core.query(self.cid,{'documento':'000.000.000-03'})['total'],2)
  with self.assertRaisesRegex(ValueError,'já foi importado'): core.import_table(self.cid,'renomeado.csv',src,p['mapping'])
  self.assertEqual(core.query(core.make_case('outro caso'))['total'],0)
 def test_one_to_many_simba(self):
  raw=(HERE/'exemplos'/'EXEMPLO_FICTICIO_simba_2010.zip').read_bytes()
  r=core.import_simba(self.cid,'teste.zip',raw);self.assertEqual(r['registros'],2)
  data=core.query(self.cid);self.assertEqual(data['resumo']['creditos'],10000)
  self.assertEqual(len(data['origens']),2);self.assertEqual(data['origens'][0]['centavos'],7000)
  self.assertIn('MARIA FICTICIA',data['registros'][0]['titular']);self.assertIn('ORIGEM_DESTINO',data['registros'][0]['local'])
 def test_mismatch_excluded(self):
  raw=(HERE/'exemplos'/'EXEMPLO_FICTICIO_simba_2010.zip').read_bytes();out=io.BytesIO()
  with zipfile.ZipFile(io.BytesIO(raw)) as z,zipfile.ZipFile(out,'w') as target:
   for n in z.namelist():
    b=z.read(n)
    if 'ORIGEM' in n: b=b.replace(b'7000',b'7001')
    target.writestr(n,b)
  r=core.import_simba(self.cid,'divergencia.zip',out.getvalue());self.assertGreater(len(r['avisos']),0)
  result=core.query(self.cid);self.assertEqual(result['resumo']['creditos'],0);self.assertEqual(result['resumo']['pendentes'],2)
 def test_orphan_or_multiple_remittances_fail(self):
  raw=(HERE/'exemplos'/'EXEMPLO_FICTICIO_simba_2010.zip').read_bytes();out=io.BytesIO()
  with zipfile.ZipFile(io.BytesIO(raw)) as z,zipfile.ZipFile(out,'w') as target:
   for n in z.namelist():
    b=z.read(n)
    if 'ORIGEM' in n: b=b.replace(b'1\t1\t3000',b'1\t99\t3000')
    target.writestr(n,b)
  with self.assertRaisesRegex(ValueError,'não foram encontradas'):core.import_simba(self.cid,'orfao.zip',out.getvalue())
  self.assertEqual(len(core.list_sources(self.cid)),0)
 def test_amounts(self):
  self.assertEqual(core.money('R$ 1.234,50'),123450);self.assertEqual(core.money('(15,20)'),-1520)
  self.assertEqual(core.money('10000',True),10000)
  for val in ['1.234','1,234','abc']:
   with self.assertRaises(ValueError): core.money(val)
 def test_ambiguous_sign_not_in_total(self):
  b=b'Data;Valor\n01/08/2026;100,00\n02/08/2026;-20,00\n'
  p=core.preview('b.csv',b);core.import_table(self.cid,'b.csv',b,p['mapping'])
  d=core.query(self.cid);self.assertEqual(d['resumo']['creditos'],0);self.assertEqual(d['resumo']['debitos'],2000);self.assertEqual(d['resumo']['pendentes'],1)
 def test_approved_rejected_and_refunded_pix(self):
  b=b'Data;Valor;Status;Nome OD\n01/08/2026;100,00;approved;ALFA\n02/08/2026;200,00;rejected;BETA\n03/08/2026;300,00;refunded;GAMA\n04/08/2026;400,00;pending;DELTA\n'
  p=core.preview('pix.csv',b);core.import_table(self.cid,'pix.csv',b,p['mapping'],fixed_nature='D')
  d=core.query(self.cid);self.assertEqual(d['total'],4);self.assertEqual(d['resumo']['debitos'],10000);self.assertEqual(d['resumo']['pendentes'],3)
  self.assertEqual(d['destinos'][0]['contraparte'],'ALFA')
 def test_refund_value_needs_review(self):
  b=b'Data;Valor;Status;Valor estornado\n01/08/2026;100,00;approved;5,00\n02/08/2026;200,00;approved;0,00\n'
  p=core.preview('estorno.csv',b);core.import_table(self.cid,'estorno.csv',b,p['mapping'],fixed_nature='C')
  d=core.query(self.cid);self.assertEqual(d['resumo']['creditos'],20000);self.assertEqual(d['resumo']['pendentes'],1)
 def test_xlsx(self):
  import openpyxl
  book=openpyxl.Workbook();sheet=book.active;sheet.title='Dados';sheet.append(['DATA_LANCAMENTO','VALOR_TRANSACAO','NATUREZA_LANCAMENTO']);sheet.append(['01/08/2026',1234.56,'C'])
  stream=io.BytesIO();book.save(stream);blob=stream.getvalue();p=core.preview('a.xlsx',blob)
  core.import_table(self.cid,'a.xlsx',blob,p['mapping'],sheet='Dados');self.assertEqual(core.query(self.cid)['resumo']['creditos'],123456)
if __name__=='__main__':unittest.main(verbosity=2)
