"""Recursos visuais locais: diagrama descritivo, evidências derivadas e relatório."""
from __future__ import annotations
import base64,datetime as dt,html,json,re,uuid,math
import core
from pathlib import Path

def schema(cid):
 with core.db(cid) as con:
  con.execute('''CREATE TABLE IF NOT EXISTS evidencias(
   id TEXT PRIMARY KEY, fonte_id TEXT NOT NULL, pagina INTEGER NOT NULL,
   descricao TEXT NOT NULL, caminho TEXT NOT NULL, sha256 TEXT NOT NULL,
   marcas TEXT NOT NULL, criada TEXT NOT NULL, FOREIGN KEY(fonte_id) REFERENCES fontes(id))''')

def source_bytes(cid,sid,kind=None):
 with core.db(cid) as con: row=con.execute('SELECT * FROM fontes WHERE id=?',(sid,)).fetchone()
 if row is None or (kind and row['tipo']!=kind): raise ValueError('Fonte não encontrada ou formato incompatível.')
 path=core.case_path(cid)/'fontes'/row['caminho']; blob=path.read_bytes()
 if core.sha(blob)!=row['sha256']: raise ValueError('O SHA-256 da fonte mudou. A operação foi bloqueada; confira o arquivo original.')
 return dict(row),blob

def archive_add(cid,name,blob):
 # Valida a estrutura sem extrair caminhos no disco.
 import io,zipfile
 with zipfile.ZipFile(io.BytesIO(blob)) as z:
  infos=[x for x in z.infolist() if not x.is_dir()]
  if len(infos)>200 or sum(x.file_size for x in infos)>150_000_000: raise ValueError('Pacote descompactado ultrapassa o limite de segurança.')
  if any(x.flag_bits & 1 for x in infos): raise ValueError('O pacote contém arquivos protegidos por senha.')
  if any(x.file_size>50_000_000 for x in infos): raise ValueError('Há arquivo acima do limite individual de 50 MB.')
 return core.insert_source(cid,name,blob,'pacote',warnings=['O pacote foi guardado e listado, mas seus arquivos internos ainda não foram importados nem analisados. Escolha os arquivos de interesse.'])

def archive_list(cid,sid):
 import io,zipfile
 meta,blob=source_bytes(cid,sid)
 if meta['tipo'] not in ('pacote','simba_bruto_2010'): raise ValueError('A fonte não é um pacote ZIP compatível.')
 with zipfile.ZipFile(io.BytesIO(blob)) as z:
  out=[]
  for idx,info in enumerate(z.infolist()):
   if info.is_dir(): continue
   ext=Path(info.filename).suffix.lower()
   kind='pdf' if ext=='.pdf' else 'planilha' if ext in ('.xlsx','.csv','.tsv') else 'outro'
   out.append({'indice':idx,'caminho':info.filename,'tamanho':info.file_size,'tipo':kind})
 return {'fonte':meta['nome'],'sha256':meta['sha256'],'itens':out}

def archive_entry(cid,sid,index):
 import io,zipfile
 meta,blob=source_bytes(cid,sid)
 if meta['tipo'] not in ('pacote','simba_bruto_2010'): raise ValueError('A fonte não é um pacote ZIP compatível.')
 with zipfile.ZipFile(io.BytesIO(blob)) as z:
  infos=z.infolist()
  try: i=infos[int(index)]
  except (IndexError,ValueError,TypeError): raise ValueError('Item do pacote não encontrado.')
  if i.is_dir() or i.file_size>50_000_000: raise ValueError('Item inválido ou excede 50 MB.')
  data=z.read(i)
  # Guardar a referência de origem no nome, sem tratar caminhos do ZIP como caminhos locais.
  inner=i.filename.replace('\\',' > ').replace('/',' > ')
  if len(inner)>230: inner='…'+inner[-229:]
  origin=meta['nome'][:100]+' [ZIP SHA256 '+meta['sha256']+'] :: '+inner
  return {'nome':origin,'conteudo':base64.b64encode(data).decode('ascii'),'extensao':Path(i.filename).suffix.lower()}

def archive_process_simba(cid,sid):
 meta,blob=source_bytes(cid,sid,'pacote'); rows,warnings=core.simba_rows(blob)
 columns=['fonte_id','local','data','titular','cpf_titular','banco','agencia','conta','contraparte','cpf_contraparte','banco_od','conta_od','descricao','centavos','natureza','chave','documento','observacao','alertas','dados_originais']
 with core.db(cid) as con:
  current=con.execute('SELECT tipo FROM fontes WHERE id=?',(sid,)).fetchone()
  if current is None or current['tipo']!='pacote': raise ValueError('O pacote já foi processado ou não está disponível.')
  con.executemany('INSERT INTO movimentos ('+','.join(columns)+') VALUES ('+','.join('?'*len(columns))+')',[(sid,)+tuple(d.get(k,'') for k in columns[1:]) for d in rows])
  con.execute('UPDATE fontes SET tipo=?,avisos=? WHERE id=?',('simba_bruto_2010',json.dumps(warnings,ensure_ascii=False),sid))
 return {'registros':len(rows),'avisos':warnings}

def save_evidence(cid,sid,page,description,blob,marks):
 schema(cid); src,_=source_bytes(cid,sid,'pdf')
 if not blob.startswith(b'\x89PNG\r\n\x1a\n') or len(blob)>8_000_000: raise ValueError('Imagem inválida ou superior a 8 MB.')
 page=int(page)
 with core.db(cid) as con:
  if con.execute('SELECT 1 FROM documentos WHERE fonte_id=? AND pagina=?',(sid,page)).fetchone() is None: raise ValueError('Página não localizada na fonte.')
 if not isinstance(marks,list) or len(marks)>100: raise ValueError('Marcações inválidas.')
 description=str(description or '').strip()[:1000]; eid=uuid.uuid4().hex
 p=core.case_path(cid)/'evidencias';p.mkdir(mode=0o700,exist_ok=True);filename=eid+'.png';(p/filename).write_bytes(blob)
 try:
  with core.db(cid) as con:con.execute('INSERT INTO evidencias VALUES (?,?,?,?,?,?,?,?)',(eid,sid,page,description,filename,core.sha(blob),json.dumps(marks,ensure_ascii=False),dt.datetime.now().isoformat(timespec='seconds')))
 except Exception:(p/filename).unlink(missing_ok=True);raise
 return {'id':eid,'sha256_imagem':core.sha(blob),'sha256_fonte':src['sha256']}

def evidences(cid):
 schema(cid)
 with core.db(cid) as con:
  return [dict(x) for x in con.execute('SELECT e.id,e.fonte_id,e.pagina,e.descricao,e.sha256,e.criada,s.nome AS fonte,s.sha256 AS sha256_fonte FROM evidencias e JOIN fontes s ON e.fonte_id=s.id ORDER BY e.criada DESC')]

def evidence_bytes(cid,eid):
 schema(cid)
 with core.db(cid) as con:
  row=con.execute('SELECT e.*,s.nome AS fonte,s.sha256 AS sha256_fonte FROM evidencias e JOIN fontes s ON e.fonte_id=s.id WHERE e.id=?',(eid,)).fetchone()
 if not row: raise ValueError('Evidência não encontrada.')
 b=(core.case_path(cid)/'evidencias'/row['caminho']).read_bytes()
 if core.sha(b)!=row['sha256']: raise ValueError('A imagem derivada foi modificada. Confira sua integridade.')
 source_bytes(cid,row['fonte_id'],'pdf')
 return dict(row),b

def brl(cents):
 cents=int(cents or 0); sign='-' if cents<0 else ''; cents=abs(cents)
 whole=f'{cents//100:,}'.replace(',','.')
 return f'{sign}R$ {whole},{cents%100:02d}'

def diagram(cid,filters):
 d=core.query(cid,filters,limit=10000)
 if d['total']>10000: raise ValueError('Aplique filtros para limitar o diagrama a no máximo 10.000 linhas.')
 # Não é permitido fundir homônimos, nomes divergentes ou titulares desconhecidos.
 owners={(r['titular'].strip(),r['cpf_titular'].strip()) for r in d['registros'] if r['centavos'] is not None and r['natureza'] in ('C','D')}
 if len(owners)!=1 or not next(iter(owners),('',''))[0]:
  raise ValueError('Para o diagrama, filtre um único titular identificado; nomes/documentos diferentes não são agrupados automaticamente.')
 name,doc=next(iter(owners));left=d['origens'][:5];right=d['destinos'][:5]
 if not left and not right: raise ValueError('Não há origens ou destinos com valores válidos para desenhar.')
 e=html.escape
 def clip(x,n=29):
  s=str(x or 'Não identificado');return s if len(s)<=n else s[:n-1]+'…'
 lines=['<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="660" viewBox="0 0 1200 660">',
 '<defs><marker id="arrow" markerWidth="10" markerHeight="10" refX="9" refY="3" orient="auto" markerUnits="strokeWidth"><path d="M0 0 L0 6 L9 3 z" fill="#35566b"/></marker></defs>',
 '<rect width="1200" height="660" fill="#f7fafc"/>',
 '<text x="600" y="40" text-anchor="middle" font-family="Arial" font-size="23" font-weight="bold" fill="#17304a">Origens e destinos das movimentações filtradas</text>',
 '<text x="245" y="75" text-anchor="middle" font-family="Arial" font-size="16" fill="#176b57">ORIGENS · CRÉDITOS</text>',
 '<text x="955" y="75" text-anchor="middle" font-family="Arial" font-size="16" fill="#a3473d">DESTINOS · DÉBITOS</text>',
 '<rect x="470" y="275" width="260" height="100" rx="11" fill="#173c58"/>',
 f'<text x="600" y="312" text-anchor="middle" font-family="Arial" font-size="18" font-weight="bold" fill="white">{e(clip(name,25))}</text>',
 f'<text x="600" y="339" text-anchor="middle" font-family="Arial" font-size="13" fill="white">{e(clip(doc,24))}</text>']
 for side,rows in [('left',left),('right',right)]:
  for idx,r in enumerate(rows):
   y=95+idx*95; x=45 if side=='left' else 870;cx=x+142
   label=clip(r['contraparte'],28);value=brl(r['centavos']);col='#176b57' if side=='left' else '#a3473d'
   lines.append(f'<rect x="{x}" y="{y}" width="285" height="72" rx="8" fill="white" stroke="#cad8e2"/>')
   lines.append(f'<text x="{cx}" y="{y+25}" text-anchor="middle" font-family="Arial" font-size="14" fill="#17304a">{e(label)}</text>')
   lines.append(f'<text x="{cx}" y="{y+49}" text-anchor="middle" font-family="Arial" font-size="15" font-weight="bold" fill="{col}">{e(value)}</text>')
   x1,y1,x2,y2=(330,y+36,470,325) if side=='left' else (730,325,870,y+36)
   lines.append(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="#35566b" stroke-width="2.5"/>')
   ang=math.atan2(y2-y1,x2-x1); size=13
   ax=x2-size*math.cos(ang-.45); ay=y2-size*math.sin(ang-.45)
   bx=x2-size*math.cos(ang+.45); by=y2-size*math.sin(ang+.45)
   lines.append(f'<polygon points="{x2},{y2} {ax:.2f},{ay:.2f} {bx:.2f},{by:.2f}" fill="#35566b"/>')
 lines+=['<text x="600" y="603" text-anchor="middle" font-family="Arial" font-size="14" fill="#435d71">Valores agregados dos registros filtrados. Mostra até cinco origens e cinco destinos.</text>',
 '<text x="600" y="628" text-anchor="middle" font-family="Arial" font-size="13" fill="#8c4a30">As setas não comprovam que uma entrada específica custeou uma saída.</text>','</svg>']
 return ''.join(lines).encode('utf-8')

def report_html(cid,filters,selected,notes):
 if not isinstance(selected,list) or len(selected)>10: raise ValueError('Selecione até 10 evidências para o relatório.')
 data=core.query(cid,filters,limit=500); cases=core.cases(); case=next((c['nome'] for c in cases if c['id']==cid),'Caso')
 try: graphic=diagram(cid,filters)
 except ValueError: graphic=None
 e=html.escape; total=data['resumo']; gen=dt.datetime.now().strftime('%d/%m/%Y %H:%M');
 def table(items):
  rows=[]
  for x in items[:15]: rows.append('<tr><td>'+e(x['contraparte'] or 'Não identificado')+'</td><td>'+e(x['cpf_contraparte'] or 'Não informado')+'</td><td>'+str(x['n'])+'</td><td>'+e(brl(x['centavos']))+'</td></tr>')
  return '<table><tr><th>Nome informado</th><th>CPF/CNPJ informado</th><th>Linhas</th><th>Valor</th></tr>'+(''.join(rows) or '<tr><td colspan="4">Não há registros válidos para os filtros.</td></tr>')+'</table>'
 source_html=''.join('<li>'+e(s['nome'])+' — SHA-256: '+e(s['sha256'])+' ('+e(s['tipo'])+')</li>' for s in core.list_sources(cid))
 images=[]
 for eid in selected:
  meta,b=evidence_bytes(cid,eid)
  uri=base64.b64encode(b).decode('ascii')
  images.append('<figure><img src="data:image/png;base64,'+uri+'"><figcaption>Imagem derivada com marcação do analista. Fonte: '+e(meta['fonte'])+'; página '+str(meta['pagina'])+'; SHA-256 da fonte: '+e(meta['sha256_fonte'])+'; SHA-256 da imagem: '+e(meta['sha256'])+'. '+e(meta['descricao'])+'</figcaption></figure>')
 diagram_html='<h2>IV - DIAGRAMA DAS MOVIMENTAÇÕES</h2><img class="diagram" src="data:image/svg+xml;base64,'+base64.b64encode(graphic).decode('ascii')+'">' if graphic else '<p>Diagrama não incluído: selecione registros de um único titular identificado.</p>'
 filters_text=', '.join(str(k)+' = '+str(v) for k,v in filters.items()) or 'Sem filtros adicionais'
 body='''<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>Relatório preliminar de análise</title><style>
 @page{size:A4;margin:2cm}body{font:12pt Georgia,serif;color:#111;line-height:1.45}header{text-align:center;border-bottom:1px solid #333;padding-bottom:10px}h1{font-size:15pt;text-align:center;margin:20px 0}h2{font-size:12pt;margin:22px 0 10px}p{text-align:justify}table{border-collapse:collapse;width:100%;font:9pt Arial,sans-serif;page-break-inside:auto}th,td{border:1px solid #a4b1ba;padding:5px;text-align:left}th{background:#dbe7f0}tr{page-break-inside:avoid}.alert{padding:10px;border-left:3px solid #b55f38;background:#fff6ed;font:10pt Arial}.small{font:9pt Arial;overflow-wrap:anywhere}img{max-width:100%;height:auto}.diagram{width:100%}figure{margin:20px 0;page-break-inside:avoid}figcaption{font:8pt Arial;overflow-wrap:anywhere}li{overflow-wrap:anywhere}footer{border-top:1px solid #aaa;margin-top:35px;padding-top:8px;font:9pt Arial}
 </style></head><body><header><b>ESTADO DO PARANÁ<br>POLÍCIA CIVIL DO PARANÁ<br>DELEGACIA DE POLÍCIA DE MAMBORÊ</b></header><h1>RELATÓRIO PRELIMINAR DE ANÁLISE FINANCEIRA</h1>'''
 body+='<p><b>Caso:</b> '+e(case)+'<br><b>Gerado em:</b> '+e(gen)+'<br><b>Filtros utilizados:</b> '+e(filters_text)+'</p>'
 body+='<div class="alert">Rascunho para revisão pela equipe. Valores correspondem aos registros filtrados, sem conciliação automática de duplicidades. Créditos e débitos podem refletir os dois lados da mesma operação.</div>'
 body+='<h2>I - OBJETO E ALCANCE</h2><p>Foram selecionadas '+str(data['total'])+' linha(s) de registros importados. O resultado depende dos arquivos recebidos, do mapeamento de colunas e dos filtros registrados acima.</p>'
 body+='<h2>II - QUANTITATIVOS DOS REGISTROS FILTRADOS</h2><ul><li>Créditos: <b>'+e(brl(total['creditos']))+'</b>.</li><li>Débitos: <b>'+e(brl(total['debitos']))+'</b>.</li><li>Registros sem valor ou natureza elegível: '+str(total['pendentes'] or 0)+'.</li></ul>'
 body+='<h2>III - ORIGENS E DESTINOS</h2><h3>Origens dos créditos</h3>'+table(data['origens'])+'<h3>Destinos dos débitos</h3>'+table(data['destinos'])+diagram_html
 body+='<h2>V - EVIDÊNCIAS SELECIONADAS</h2>'+(''.join(images) if images else '<p>Nenhuma imagem marcada foi selecionada para este relatório.</p>')
 body+='<h2>VI - OBSERVAÇÕES DO ANALISTA</h2><p>'+e(str(notes or '')[:10000]).replace('\n','<br>')+'</p><h2>VII - FONTES NO CASO</h2><ul class="small">'+source_html+'</ul>'
 body+='<p>Os dados e imagens devem ser conferidos com os originais. O diagrama descreve operações agregadas; a sequência temporal ou semelhança de valor, isoladamente, não prova que a mesma quantia transitou entre todas as pessoas indicadas.</p><footer>Delegacia de Polícia de Mamborê — Rascunho para revisão</footer></body></html>'
 return body.encode('utf-8')
