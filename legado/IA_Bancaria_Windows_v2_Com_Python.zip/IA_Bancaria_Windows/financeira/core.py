"""Importação e cálculos locais, com rastreabilidade. Protótipo para validação humana."""
from __future__ import annotations
import base64, csv, datetime as dt, hashlib, io, json, os, re, sqlite3, unicodedata, uuid, zipfile
from collections import Counter, defaultdict
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path

ROOT = Path(os.environ.get('FINANCEIRA_HOME', Path(__file__).resolve().parents[1])).resolve()
DATA = ROOT / 'dados'
DATA.mkdir(mode=0o700, parents=True, exist_ok=True)
FIELDS = {
 'data':'Data da operação', 'titular':'Nome do titular', 'cpf_titular':'CPF/CNPJ do titular',
 'banco':'Banco do titular', 'agencia':'Agência do titular', 'conta':'Conta do titular',
 'contraparte':'Nome da origem/destino', 'cpf_contraparte':'CPF/CNPJ da origem/destino',
 'banco_od':'Banco da origem/destino', 'conta_od':'Conta da origem/destino',
 'descricao':'Descrição/histórico', 'valor':'Valor da transação', 'natureza':'Natureza: crédito/débito',
 'credito':'Coluna de créditos', 'debito':'Coluna de débitos', 'chave':'Chave do lançamento',
 'documento':'Documento/referência', 'observacao':'Observação', 'status':'Situação da operação', 'modalidade':'Modalidade informada', 'estorno':'Valor de estorno/devolução'
}
ALIASES = {
 'data':['data_lancamento','data_transacao','data_movimentacao','data_operacao','pyn_created_date','pyt_created_dt','data','dt_lancamento'],
 'titular':['nome_titular','pyn_collector_name','pyt_prvdr_data_src_name','titular','cliente','nome_do_titular'],
 'cpf_titular':['cpf_cnpj_titular','pyn_collector_identification_number','pyt_prvdr_data_src_cpf_cnpj','cpf_titular','documento_titular'],
 'banco':['nome_banco','numero_banco','banco','instituicao'], 'agencia':['numero_agencia','agencia'],
 'conta':['numero_conta','conta','conta_corrente'],
 'contraparte':['nome_pessoa_od','nome_od','pyn_payer_name','pyt_prvdr_data_dest_holder','nome_beneficiario','beneficiario','nome_contraparte','nome_ordenante'],
 'cpf_contraparte':['cpf_cnpj_od','pyn_payer_identification_number','pyt_prvdr_data_dest_ident_number','cpf_cnpj_beneficiario','documento_beneficiario','cpf_cnpj_contraparte','cpf_cnpj_ordenante'],
 'banco_od':['numero_banco_od','pyt_prvdr_data_dest_bank_name','banco_od','banco_beneficiario'],
 'conta_od':['numero_conta_od','pyt_prvdr_data_dest_number','conta_od','conta_beneficiario'],
 'descricao':['descricao_lancamento','payout_desc','historico','descricao','lancamento','historico_complementar'],
 'valor':['valor_transacao','valor_lancamento','pyn_transaction_amt','payout_amt','valor','valor_movimentacao','valor_operacao'],
 'natureza':['natureza_lancamento','natureza','tipo_movimentacao','tipo_lancamento','credito_debito','tipo'],
 'credito':['credito','valor_credito','entrada'], 'debito':['debito','valor_debito','saida'],
 'chave':['codigo_chave_extrato','chave_extrato','id_lancamento'],
 'documento':['numero_documento_transacao','pyn_ext_ref_e2e_id','pyt_extrnl_idntf_dstn_id','numero_documento','documento','id_transacao','end_to_end'],
 'observacao':['observacao','informacoes_adicionais','complemento'],
 'status':['pyn_status','payout_status','status','situacao','situacao_operacao','status_transacao'],
 'modalidade':['payout_type','metodo_pagamento','tipo_pagamento','pyn_type','modalidade'],
 'estorno':['pyn_refunded_amt','valor_estornado','valor_devolvido','valor_estorno']
}

def norm(s):
 s=unicodedata.normalize('NFKD',str(s or '')).encode('ascii','ignore').decode().lower()
 return re.sub(r'[^a-z0-9]+','_',s).strip('_')

def make_case(name):
 name=str(name or '').strip()
 if not name or len(name)>100: raise ValueError('Informe um nome para o caso (até 100 caracteres).')
 cid=uuid.uuid4().hex[:16]; p=DATA/cid; p.mkdir(mode=0o700); (p/'fontes').mkdir(mode=0o700)
 (p/'caso.json').write_text(json.dumps({'id':cid,'nome':name,'criado':dt.datetime.now().isoformat(timespec='seconds')},ensure_ascii=False),encoding='utf-8')
 with db(cid) as con: con.executescript('''
 CREATE TABLE fontes(id TEXT PRIMARY KEY,nome TEXT NOT NULL,sha256 TEXT NOT NULL UNIQUE,tipo TEXT NOT NULL,criado TEXT NOT NULL,caminho TEXT NOT NULL,avisos TEXT DEFAULT '');
 CREATE TABLE movimentos(id INTEGER PRIMARY KEY,fonte_id TEXT NOT NULL,local TEXT NOT NULL,data TEXT,titular TEXT,cpf_titular TEXT,banco TEXT,agencia TEXT,conta TEXT,contraparte TEXT,cpf_contraparte TEXT,banco_od TEXT,conta_od TEXT,descricao TEXT,centavos INTEGER,natureza TEXT,chave TEXT,documento TEXT,observacao TEXT,alertas TEXT,dados_originais TEXT NOT NULL,FOREIGN KEY(fonte_id) REFERENCES fontes(id));
 CREATE INDEX movimentos_fonte ON movimentos(fonte_id);
 CREATE INDEX movimentos_data ON movimentos(data);
 CREATE TABLE documentos(id INTEGER PRIMARY KEY,fonte_id TEXT NOT NULL,pagina INTEGER NOT NULL,texto TEXT NOT NULL,FOREIGN KEY(fonte_id) REFERENCES fontes(id));
 ''')
 return cid

def case_path(cid):
 if not re.fullmatch(r'[a-f0-9]{16}',str(cid or '')): raise ValueError('Caso inválido.')
 p=DATA/cid
 if not (p/'caso.json').is_file(): raise ValueError('Caso não encontrado.')
 return p

def db(cid):
 p=case_path(cid); con=sqlite3.connect(p/'dados.sqlite3'); con.row_factory=sqlite3.Row
 con.execute('PRAGMA foreign_keys=ON'); con.create_function('NORM',1,norm)
 con.create_function('DIGITS',1,lambda value:re.sub(r'\D','',str(value or '')))
 return con

def cases():
 result=[]
 for p in DATA.iterdir():
  if p.is_dir() and re.fullmatch(r'[a-f0-9]{16}',p.name):
   try: result.append(json.loads((p/'caso.json').read_text(encoding='utf-8')))
   except (OSError,ValueError): pass
 return sorted(result,key=lambda x:x['criado'],reverse=True)

def sha(b): return hashlib.sha256(b).hexdigest()

def decode(b):
 for encoding in ('utf-8-sig','cp1252','latin1'):
  try: return b.decode(encoding),encoding
  except UnicodeDecodeError: continue
 raise ValueError('Codificação do arquivo não reconhecida.')

def clean(x):
 if x is None: return ''
 if isinstance(x,(dt.date,dt.datetime)): return x.isoformat()[:10]
 if isinstance(x,float) and x.is_integer(): return str(int(x))
 return str(x).strip()

def money(value, implied_cents=False):
 s=clean(value).replace('\u00a0',' ').strip()
 if not s: return None
 if implied_cents:
  if not s.isdigit(): raise ValueError('Valor SIMBA deveria conter apenas números em centavos.')
  return int(s)
 neg=(s.startswith('(') and s.endswith(')')) or s.endswith('-') or s.startswith('-')
 s=re.sub(r'(?i)R\$|\s','',s).strip('()+-')
 if not re.fullmatch(r'[0-9.,]+',s): raise ValueError('Valor inválido: '+clean(value)[:50])
 if ',' in s and '.' in s:
  if s.rfind(',')>s.rfind('.'): s=s.replace('.','').replace(',','.')
  else: s=s.replace(',','')
 elif ',' in s:
  parts=s.split(',')
  if len(parts)!=2: raise ValueError('Valor ambíguo: '+s)
  s=s.replace(',','.')
 elif s.count('.')>1: raise ValueError('Valor ambíguo: '+s)
 if '.' in s and len(s.rsplit('.',1)[1])>2:
  raise ValueError('Valor com separador ou fração ambígua: '+s)
 try:
  n=Decimal(s)
  if not n.is_finite() or n>Decimal('99999999999999'): raise ValueError('Valor fora do limite.')
  cents=int((n*100).quantize(Decimal('1'),rounding=ROUND_HALF_UP))
  return -cents if neg else cents
 except InvalidOperation: raise ValueError('Valor inválido: '+clean(value)[:50])

def parse_date(x):
 s=clean(x)
 if not s: return ''
 for fmt in ('%Y-%m-%d','%d/%m/%Y','%d-%m-%Y','%d.%m.%Y','%Y/%m/%d','%d%m%Y','%Y%m%d'):
  try: return dt.datetime.strptime(s[:10] if len(s)>10 else s,fmt).date().isoformat()
  except ValueError: pass
 return ''

def direction(value, cents=None, positive_credit=False):
 s=norm(value)
 if s in ('c','credito','credit','entrada','creditado','deposito_recebido'): return 'C'
 if s in ('d','debito','debit','saida','debitado'): return 'D'
 if not s and cents is not None and cents<0: return 'D'
 if not s and cents is not None and cents>0 and positive_credit: return 'C'
 return '?'

def auto_mapping(headers):
 look={norm(h):i for i,h in reversed(list(enumerate(headers)))}
 return {k:next((look[a] for a in v if a in look),None) for k,v in ALIASES.items()}

def input_rows(name, blob, sheet=None, headerrow=1):
 ext=Path(name).suffix.lower(); headerrow=int(headerrow)
 if not 1<=headerrow<=100: raise ValueError('A linha de cabeçalho deve estar entre 1 e 100.')
 if ext in ('.csv','.txt','.tsv'):
  txt,enc=decode(blob)
  try: dialect=csv.Sniffer().sniff(txt[:16384],delimiters=';,\t|')
  except csv.Error: dialect=csv.excel
  vals=list(csv.reader(io.StringIO(txt,newline=''),dialect))
  tab='Arquivo'; sheets=[]
 elif ext=='.xlsx':
  import openpyxl
  with zipfile.ZipFile(io.BytesIO(blob)) as package:
   members=package.infolist()
   if len(members)>10000 or sum(i.file_size for i in members)>250_000_000:
    raise ValueError('Planilha descompactada excede o limite de segurança.')
  wb=openpyxl.load_workbook(io.BytesIO(blob),read_only=True,data_only=True,keep_links=False)
  sheets=wb.sheetnames
  if not sheets: raise ValueError('A planilha está vazia.')
  if sheet is not None and sheet not in sheets: raise ValueError('Aba não encontrada.')
  tab=sheet or sheets[0]; ws=wb[tab]
  vals=[]
  for row in ws.iter_rows(values_only=True):
   if len(vals)>=200000: raise ValueError('Aba excede o limite de 200.000 linhas.')
   vals.append([clean(x) for x in row])
  wb.close(); enc='xlsx'
 else: raise ValueError('Use CSV, TXT delimitado ou XLSX para planilha.')
 if len(vals)<headerrow: raise ValueError('Não há linha de cabeçalho nessa posição.')
 headers=[clean(v) or f'Coluna {i+1}' for i,v in enumerate(vals[headerrow-1])]
 if not headers or len(set(headers))!=len(headers):
  # Column positions, not the text, are the stable identities.
  headers=[f'{v} [coluna {i+1}]' if headers.count(v)>1 else v for i,v in enumerate(headers)]
 rows=[(i+1,[clean(x) for x in row]) for i,row in enumerate(vals) if i>=headerrow and any(clean(x) for x in row)]
 return {'headers':headers,'rows':rows,'sheet':tab,'sheets':sheets,'encoding':enc,'headerrow':headerrow}

def preview(name, blob, sheet=None, headerrow=1):
 r=input_rows(name,blob,sheet,headerrow)
 if len(r['headers'])==1: raise ValueError('Apenas uma coluna foi encontrada. Para SIMBA bruto, envie um ZIP com EXTRATO e ORIGEM_DESTINO; para outros arquivos, confira o delimitador.')
 return {'headers':r['headers'],'mapping':auto_mapping(r['headers']),'sample':[{'linha':i,'celulas':row} for i,row in r['rows'][:5]],'sheets':r['sheets'],'sheet':r['sheet'],'encoding':r['encoding'],'headerrow':r['headerrow'],'total_rows':len(r['rows'])}

def package_files(blob):
 if len(blob)>50_000_000: raise ValueError('ZIP excede o limite de 50 MB.')
 with zipfile.ZipFile(io.BytesIO(blob)) as z:
  infos=[x for x in z.infolist() if not x.is_dir()]
  if len(infos)>100 or sum(x.file_size for x in infos)>150_000_000: raise ValueError('ZIP muito grande ou com arquivos demais.')
  found=defaultdict(list)
  for info in infos:
   nm=norm(Path(info.filename).stem)
   if not info.filename.lower().endswith('.txt'): continue
   if 'origem_destino' in nm or 'origemdestino' in nm: found['od'].append(info)
   elif 'extrato' in nm: found['extrato'].append(info)
   elif 'titulares' in nm: found['titulares'].append(info)
  if len(found['extrato'])!=1 or len(found['od'])!=1 or len(found['titulares'])>1:
   raise ValueError('O ZIP deve conter exatamente um EXTRATO.txt e um ORIGEM_DESTINO.txt da mesma remessa e, opcionalmente, um TITULARES.txt. Separe os arquivos por banco/remessa.')
  result={k:(infos_[0].filename,z.read(infos_[0])) for k,infos_ in found.items()}
  used={info[0] for info in result.values()}
  result['_nao_processados']=[i.filename for i in infos if i.filename not in used]
  return result

def simba_rows(blob):
 files=package_files(blob)
 def records(which):
  if which not in files: return []
  text,_=decode(files[which][1]); return [(i,row) for i,row in enumerate(csv.reader(io.StringIO(text,newline=''),delimiter='\t'),start=1) if any(row)]
 ex=records('extrato'); od=records('od'); ts=records('titulares')
 if not ex: raise ValueError('EXTRATO vazio.')
 if any(len(row)!=14 for _,row in ex) or any(len(row)!=18 for _,row in od):
  raise ValueError('Leiaute SIMBA bruto diferente da Carta-Circular 3.454/2010 (14 campos no EXTRATO e 18 no ORIGEM_DESTINO). O leiaute novo ou divergente ainda não está validado. Use por ora um extrato detalhado CSV/XLSX.')
 if ts and any(len(row)<9 for _,row in ts): raise ValueError('Arquivo TITULARES com leiaute inesperado.')
 # Chave é única apenas dentro desta remessa. Não cruzar remessas/bancos.
 exmap={}
 for line,r in ex:
  key=r[0].strip()
  if not key or key in exmap: raise ValueError('Chave de extrato vazia ou repetida na remessa: revise o arquivo antes de importar.')
  exmap[key]=(line,r)
 ods=defaultdict(list); odkeys=set()
 for line,r in od:
  if not r[0].strip() or r[0] in odkeys: raise ValueError('Chave de origem/destino vazia ou repetida.')
  odkeys.add(r[0]); ods[r[1].strip()].append((line,r))
 orphan=[k for k in ods if k not in exmap]
 if orphan: raise ValueError(f'{len(orphan)} chave(s) em ORIGEM_DESTINO não foram encontradas no EXTRATO. Importação bloqueada.')
 owners=defaultdict(list)
 for lineno,r in ts:
  # Apenas titulares e cotitulares; representantes e procuradores não viram titulares.
  role=r[4].strip().upper()
  if role=='T' or (role.isdigit() and role!='0'):
   owners[tuple(r[:4])].append((r[8],r[7],lineno))
 result=[]; warnings=[]
 if not ts: warnings.append('TITULARES não informado; o nome do titular poderá ficar vazio.')
 if files.get('_nao_processados'):
  warnings.append(str(len(files['_nao_processados']))+' outro(s) arquivo(s) do ZIP não foram processados nesta importação. Consulte os arquivos e importe documentos/planilhas separadamente.')
 for key,(line,r) in exmap.items():
  linked=ods.get(key,[])
  if not linked: warnings.append(f'EXTRATO linha {line}: sem origem/destino vinculada.')
  who=owners.get(tuple(r[1:5]),[])
  if len(who)>1: warnings.append(f'EXTRATO linha {line}: {len(who)} titulares/cotitulares. Veja todos no registro; não significa que cada um movimentou a conta.')
  try: amount=money(r[9],True)
  except ValueError: raise ValueError(f'Valor inválido em EXTRATO linha {line}.')
  total=0; vals=[]
  for odline,x in linked:
   try: part=money(x[2],True)
   except ValueError: raise ValueError(f'Valor inválido em ORIGEM_DESTINO linha {odline}.')
   total+=part; vals.append((odline,x,part))
  if linked and total!=amount:
   warnings.append(f'EXTRATO linha {line}: valor do lançamento difere da soma das origens/destinos; confira a fonte.')
  # As parcelas são exibidas; no cálculo usam-se parcelas apenas quando conciliadas.
  calc=bool(linked and total==amount)
  if not vals: vals=[(None,None,amount)]
  for odline,x,part in vals:
   alerts=[]
   if not calc and linked: alerts.append('Divergência de valores entre EXTRATO e ORIGEM_DESTINO: excluído dos totais até revisão.')
   if not parse_date(r[5]): alerts.append('Data não reconhecida.')
   nature=direction(r[10]);
   if nature=='?': alerts.append('Natureza não é crédito nem débito; excluído dos totais.')
   names=' | '.join(clean(t[0]) for t in who); docs=' | '.join(clean(t[1]) for t in who)
   d={'data':parse_date(r[5]),'titular':names,'cpf_titular':docs,'banco':r[1], 'agencia':r[2], 'conta':r[3],
      'contraparte':x[10] if x else '', 'cpf_contraparte':x[9] if x else '', 'banco_od':x[4] if x else '', 'conta_od':x[6] if x else '',
      'descricao':r[7], 'centavos':part if calc or not linked else None,'natureza':nature, 'chave':key,'documento':x[3] if x else r[6],
      'observacao':x[17] if x else '', 'alertas':' | '.join(alerts),
      'local':files['extrato'][0]+f' linha {line}'+(' + '+files['od'][0]+f' linha {odline}' if x else ''),
      'dados_originais':json.dumps({'extrato':r,'origem_destino':x,'titulares':who},ensure_ascii=False)}
   result.append(d)
 return result,warnings

def insert_source(cid,name,blob,tipo,rows=None,warnings=None,pages=None):
 p=case_path(cid); digest=sha(blob); sid=uuid.uuid4().hex; filename=sid+Path(name).suffix.lower()[:10]
 warns=warnings or []
 with db(cid) as con:
  if con.execute('SELECT 1 FROM fontes WHERE sha256=?',(digest,)).fetchone(): raise ValueError('Este arquivo já foi importado neste caso (mesmo SHA-256).')
  # Os bytes são iguais aos recebidos e o nome original é guardado à parte.
  (p/'fontes'/filename).write_bytes(blob)
  try:
   con.execute('INSERT INTO fontes VALUES (?,?,?,?,?,?,?)',(sid,Path(name).name,digest,tipo,dt.datetime.now().isoformat(timespec='seconds'),filename,json.dumps(warns,ensure_ascii=False)))
   columns=['fonte_id','local','data','titular','cpf_titular','banco','agencia','conta','contraparte','cpf_contraparte','banco_od','conta_od','descricao','centavos','natureza','chave','documento','observacao','alertas','dados_originais']
   if rows:
    con.executemany('INSERT INTO movimentos ('+','.join(columns)+') VALUES ('+','.join('?'*len(columns))+')',[(sid,)+tuple(d.get(k,'') for k in columns[1:]) for d in rows])
   if pages: con.executemany('INSERT INTO documentos (fonte_id,pagina,texto) VALUES (?,?,?)',[(sid,n,t) for n,t in pages])
  except Exception:
   (p/'fontes'/filename).unlink(missing_ok=True); raise
 return {'id':sid,'sha256':digest,'registros':len(rows or []),'avisos':warns,'paginas':len(pages or [])}

def import_table(cid,name,blob,mapping,sheet=None,headerrow=1,positive_credit=False,fixed_nature=''):
 x=input_rows(name,blob,sheet,headerrow); n=len(x['headers'])
 if not isinstance(mapping,dict): raise ValueError('Mapeamento inválido.')
 mp={}
 for k in FIELDS:
  val=mapping.get(k)
  if val is not None and val!='':
   if not isinstance(val,int) or val<0 or val>=n: raise ValueError('Coluna inválida: '+k)
   mp[k]=val
 if 'data' not in mp or ('valor' not in mp and 'credito' not in mp and 'debito' not in mp): raise ValueError('Mapeie ao menos data e valor, ou data e colunas separadas de crédito/débito.')
 if 'valor' in mp and ('credito' in mp or 'debito' in mp): raise ValueError('Escolha valor único OU crédito/débito separados, não ambos.')
 def val(row,key):
  idx=mp.get(key); return row[idx] if idx is not None and idx<len(row) else ''
 result=[]; warnings=['Cada linha é tratada como um registro. Exportações detalhadas podem ter várias linhas por lançamento; confira a granularidade e a coluna de valor antes de somar.', 'Valores podem aparecer em ambos os lados de uma transferência entre contas importadas. Não some débitos e créditos como dinheiro novo.']
 for line,row in x['rows']:
  alerts=[]; data=parse_date(val(row,'data'))
  if not data: alerts.append('Data ausente ou não reconhecida.')
  try:
   if 'valor' in mp:
    amount=money(val(row,'valor')); nat=direction(val(row,'natureza'),amount,positive_credit)
    if not val(row,'natureza') and fixed_nature in ('C','D'): nat=fixed_nature
    if amount is not None and amount<0 and nat=='C': alerts.append('Sinal negativo diverge da natureza crédito.'); amount=None
    elif amount is not None: amount=abs(amount)
   else:
    c=money(val(row,'credito')); d=money(val(row,'debito'))
    if c not in (None,0) and d not in (None,0): alerts.append('Crédito e débito preenchidos na mesma linha.'); amount=None; nat='?'
    elif c not in (None,0): amount=abs(c); nat='C'
    elif d not in (None,0): amount=abs(d); nat='D'
    else: amount=None; nat='?'
  except ValueError as e: amount=None; nat='?'; alerts.append(str(e))
  status=val(row,'status')
  if 'status' in mp:
   accepted={'approved','aprovado','aprovada','concluido','concluida','efetivado','efetivada','completed','pago','paga','liquidado','liquidada'}
   if norm(status) not in accepted:
    alerts.append('Situação não confirmada como concluída ('+(status or 'vazia')+'); excluído dos totais. O valor original permanece nos detalhes.')
    amount=None
  if 'estorno' in mp and val(row,'estorno'):
   try:
    returned=money(val(row,'estorno'))
    if returned not in (None,0):
     alerts.append('Valor de estorno/devolução informado; operação excluída dos totais até conferência da reversão.')
     amount=None
   except ValueError:
    alerts.append('Valor de estorno não reconhecido; operação excluída dos totais até conferência.')
    amount=None
  if amount is None: alerts.append('Valor não calculado ou excluído; registro fora dos totais.')
  if nat=='?': alerts.append('Natureza não reconhecida; registro excluído dos totais.')
  item={key:val(row,key) for key in FIELDS if key not in ('credito','debito','valor','natureza','data','status','modalidade','estorno')}
  if status: item['observacao']=(item.get('observacao','')+' | Situação informada: '+status).strip(' |')
  modality=val(row,'modalidade')
  if modality: item['observacao']=(item.get('observacao','')+' | Modalidade informada: '+modality).strip(' |')
  item.update({'data':data,'centavos':amount,'natureza':nat,'alertas':' | '.join(alerts),'local':f'{x["sheet"]}, linha {line}',
    'dados_originais':json.dumps({'colunas':x['headers'],'valores':row},ensure_ascii=False)})
  result.append(item)
 return insert_source(cid,name,blob,'planilha',result,warnings)

def import_simba(cid,name,blob):
 rows,warnings=simba_rows(blob); return insert_source(cid,name,blob,'simba_bruto_2010',rows,warnings)

def import_pdf(cid,name,blob):
 from pypdf import PdfReader
 r=PdfReader(io.BytesIO(blob),strict=False)
 if r.is_encrypted: raise ValueError('PDF protegido por senha; obtenha uma cópia autorizada e desbloqueada.')
 if len(r.pages)>1000: raise ValueError('PDF excede o limite de 1.000 páginas.')
 pages=[]
 for i,page in enumerate(r.pages,1): pages.append((i,(page.extract_text() or '')[:200_000]))
 words=sum(len(x[1].strip()) for x in pages)
 warnings=['Texto extraído para consulta; transações em PDF não são automaticamente convertidas em lançamentos.', 'PDF sem texto selecionável ou com pouco texto: provavelmente requer OCR externo e revisão.'] if words<50 else ['Texto extraído para consulta; transações em PDF não são automaticamente convertidas em lançamentos. Confira a extração com as páginas originais.']
 return insert_source(cid,name,blob,'pdf',warnings=warnings,pages=pages)

def list_sources(cid):
 with db(cid) as con:
  return [dict(x) for x in con.execute('SELECT id,nome,sha256,tipo,criado,avisos FROM fontes ORDER BY criado DESC')]

def query(cid,filters=None,limit=500):
 f=filters or {}; clauses=[]; args=[]
 for k,col in [('titular','titular'),('contraparte','contraparte'),('documento','cpf_titular || \' \' || cpf_contraparte'),('banco','banco'),('texto','descricao || \' \' || observacao || \' \' || documento')]:
  if str(f.get(k,'')).strip():
   if k=='documento':
    digits=re.sub(r'\D','',str(f[k]))
    if not digits: raise ValueError('Informe ao menos um dígito no filtro de CPF/CNPJ.')
    clauses.append("(DIGITS(cpf_titular) LIKE ? OR DIGITS(cpf_contraparte) LIKE ?)"); args.extend(['%'+digits+'%','%'+digits+'%'])
   else:
    needle=norm(f[k]).replace('!','!!').replace('%','!%').replace('_','!_')
    clauses.append('NORM(COALESCE('+col+",'')) LIKE ? ESCAPE '!'"); args.append('%'+needle+'%')
 if f.get('de'): clauses.append('data>=?'); args.append(f['de'])
 if f.get('ate'): clauses.append('data<=?'); args.append(f['ate'])
 if f.get('natureza') in ('C','D','?'): clauses.append('natureza=?'); args.append(f['natureza'])
 if f.get('fonte'): clauses.append('fonte_id=?'); args.append(f['fonte'])
 for key,op in [('min','>='),('max','<=')]:
  if f.get(key) not in (None,''):
   num=money(f[key]); clauses.append('centavos'+op+'?'); args.append(num)
 where=' WHERE '+' AND '.join(clauses) if clauses else ''
 sql=' FROM movimentos m JOIN fontes s ON s.id=m.fonte_id'+where
 with db(cid) as con:
  n=con.execute('SELECT COUNT(*)'+sql,args).fetchone()[0]
  totals=dict(con.execute("SELECT COALESCE(SUM(CASE WHEN natureza='C' THEN centavos ELSE 0 END),0) creditos,COALESCE(SUM(CASE WHEN natureza='D' THEN centavos ELSE 0 END),0) debitos,SUM(CASE WHEN natureza='?' OR centavos IS NULL THEN 1 ELSE 0 END) pendentes"+sql,args).fetchone())
  cols='m.id,m.fonte_id,m.local,m.data,m.titular,m.cpf_titular,m.banco,m.agencia,m.conta,m.contraparte,m.cpf_contraparte,m.banco_od,m.conta_od,m.descricao,m.centavos,m.natureza,m.chave,m.documento,m.observacao,m.alertas,s.nome AS fonte,s.sha256'
  rows=[dict(x) for x in con.execute('SELECT '+cols+sql+' ORDER BY m.data DESC,m.id DESC LIMIT ?',args+[min(int(limit),10000)])]
  ranks={}
  for label,nature in [('destinos','D'),('origens','C')]:
   statement='SELECT m.contraparte,m.cpf_contraparte,COUNT(*) n,SUM(m.centavos) centavos'+sql+(' AND ' if where else ' WHERE ')+"m.natureza=? AND m.centavos IS NOT NULL GROUP BY m.contraparte,m.cpf_contraparte ORDER BY centavos DESC LIMIT 30"
   ranks[label]=[dict(x) for x in con.execute(statement,args+[nature])]
 return {'total':n,'resumo':totals,'registros':rows,**ranks}

def pdf_pages(cid,source):
 with db(cid) as con:
  meta=con.execute('SELECT nome,sha256 FROM fontes WHERE id=? AND tipo=\'pdf\'',(source,)).fetchone()
  if meta is None: raise ValueError('PDF não encontrado.')
  rows=con.execute('SELECT pagina,texto FROM documentos WHERE fonte_id=? ORDER BY pagina',(source,)).fetchall()
 return {'fonte':dict(meta),'paginas':[dict(x) for x in rows]}
