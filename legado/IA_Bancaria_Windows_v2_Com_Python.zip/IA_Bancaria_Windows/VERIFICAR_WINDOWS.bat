@echo off
setlocal
chcp 65001 >nul
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
set "PYTHONDONTWRITEBYTECODE=1"
cd /d "%~dp0"
title Diagnostico da Analise Bancaria
if not exist "%~dp0runtime_windows\python.exe" (
 echo Python portatil ausente. Extraia novamente todo o pacote ZIP.
 pause
 exit /b 1
)
"%~dp0runtime_windows\python.exe" -X utf8 -u "%~dp0diagnosticar_windows.py" > "%~dp0diagnostico_windows.txt" 2>&1
type "%~dp0diagnostico_windows.txt"
echo.
echo O resultado foi salvo em diagnostico_windows.txt nesta pasta.
pause
