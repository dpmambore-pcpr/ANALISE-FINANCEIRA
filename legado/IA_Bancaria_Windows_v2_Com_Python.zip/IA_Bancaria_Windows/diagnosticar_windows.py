"""Verifica apenas o ambiente de execução; não lê arquivos dos casos."""
import importlib
import socket
import sqlite3
import sys
import tempfile
import traceback
from pathlib import Path
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'vendor'))
print('DIAGNOSTICO DA ANALISE BANCARIA LOCAL')
print('Python:',sys.version.split()[0])
print('Arquitetura:', '64 bits' if sys.maxsize>2**32 else '32 bits')
failed=False
for module in ('openpyxl','et_xmlfile','pypdf','ssl','sqlite3','webbrowser'):
 try:
  result=importlib.import_module(module)
  print(module+': OK',getattr(result,'__version__',''))
 except Exception:
  failed=True; print(module+': FALHA');traceback.print_exc()
try:
 with tempfile.TemporaryFile(dir=root) as f:f.write(b'teste')
 print('Gravacao na pasta: OK')
except Exception:
 failed=True;print('Gravacao na pasta: FALHA');traceback.print_exc()
try:
 with socket.socket() as s:s.bind(('127.0.0.1',0))
 print('Porta local: OK')
except Exception:
 failed=True;print('Porta local: FALHA');traceback.print_exc()
for rel in ('iniciar.py','financeira/app.py','financeira/core.py','financeira/visuais.py','financeira/web/index.html'):
 ok=(root/rel).is_file();print(rel+': '+('OK' if ok else 'AUSENTE'));failed=failed or not ok
print('\nResultado:', 'Falha detectada; envie este resultado para verificacao.' if failed else 'Verificacoes basicas OK. Abra INICIAR_WINDOWS para usar o programa.')
sys.exit(1 if failed else 0)
