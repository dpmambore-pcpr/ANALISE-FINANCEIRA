@echo off
setlocal
chcp 65001 >nul
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
set "PYTHONDONTWRITEBYTECODE=1"
cd /d "%~dp0"
title Analise Bancaria Local
if not exist "%~dp0iniciar.py" goto pasta_incompleta
if not exist "%~dp0runtime_windows\python.exe" goto runtime_ausente
echo Abrindo Analise Bancaria Local com o Python incluido nesta pasta...
echo Mantenha esta janela aberta enquanto usa o programa.
echo.
"%~dp0runtime_windows\python.exe" -X utf8 -u "%~dp0iniciar.py"
if errorlevel 1 goto erro_programa
echo.
echo O programa foi encerrado.
goto fim
:pasta_incompleta
echo A pasta do programa esta incompleta.
echo Clique com o botao direito no arquivo ZIP e escolha Extrair Tudo.
echo Depois abra INICIAR_WINDOWS na pasta extraida.
goto fim
:runtime_ausente
echo O Python portatil nao foi encontrado na pasta runtime_windows.
echo Extraia novamente TODO o pacote IA_Bancaria_Windows_v2_Com_Python.zip.
echo Nao e preciso instalar Python nem abrir a Microsoft Store.
goto fim
:erro_programa
echo.
echo Nao foi possivel abrir o programa. A mensagem de erro aparece acima.
echo Execute VERIFICAR_WINDOWS nesta mesma pasta e envie uma foto do resultado.
:fim
echo.
pause
